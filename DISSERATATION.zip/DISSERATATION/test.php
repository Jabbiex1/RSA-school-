<?php
session_start();

if (!isset($_SESSION['studentID']) || !isset($_SESSION['class'])) {
    header("Location: student-login.php");
    exit();
}

$studentID = htmlspecialchars($_SESSION['studentID']);
$class = htmlspecialchars($_SESSION['class']);

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: student-login.php");
    exit();
}

$host = 'localhost';
$db = 'royal_academy';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

function getLetterGrade($total) {
    if ($total >= 90) return 'A';
    if ($total >= 80) return 'B';
    if ($total >= 70) return 'C';
    if ($total >= 60) return 'D';
    return 'F';
}

// Term selection
$termSelected = $_POST['term'] ?? 'First Term';
$termsOrder = ['First Term', 'Second Term', 'Third Term'];

// Terms to show based on selection
$termsToShow = [];
foreach ($termsOrder as $t) {
    $termsToShow[] = $t;
    if ($t === $termSelected) break;
}

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Student name
    $stmt = $pdo->prepare("SELECT name FROM students WHERE id = ?");
    $stmt->execute([$studentID]);
    $student = $stmt->fetch();
    $studentName = $student['name'] ?? 'Student Name';

    // Fetch grades
    $grades = [];
    $averages = [];
    foreach ($termsToShow as $term) {
        $stmtGrades = $pdo->prepare("SELECT subject, assignment, test, exam FROM grades WHERE student_id = ? AND terms = ?");
        $stmtGrades->execute([$studentID, $term]);
        $rows = $stmtGrades->fetchAll();
        $totalSum = 0;
        $subjectCount = count($rows);

        foreach ($rows as $row) {
            $assignment = is_numeric($row['assignment']) ? (float)$row['assignment'] : 0;
            $test = is_numeric($row['test']) ? (float)$row['test'] : 0;
            $exam = is_numeric($row['exam']) ? (float)$row['exam'] : 0;
            $total = $assignment + $test + $exam;

            $grades[$row['subject']][$term] = [
                'assignment' => $assignment,
                'test' => $test,
                'exam' => $exam,
                'total' => $total,
                'letter' => getLetterGrade($total)
            ];
            $totalSum += $total;
        }

        $averages[$term] = $subjectCount ? $totalSum / $subjectCount : 0;
    }

    // Cumulative average capped at 100
    $cumulativeAverage = min(array_sum($averages)/count($averages), 100);

    // Overall position
    $stmtPos = $pdo->prepare("SELECT position FROM positions WHERE student_id = ?");
    $stmtPos->execute([$studentID]);
    $positionRow = $stmtPos->fetch();
    $overallPosition = $positionRow ? $positionRow['position'] : 'N/A';

} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Student Dashboard - Royal Science Academy</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8; margin: 0; padding: 0;
    display: flex; flex-direction: column; align-items: center;
}
header {
    width: 100%; max-width: 950px; padding: 1rem 2rem;
    background: #004aad; color: #fff; border-radius: 8px 8px 0 0;
    display: flex; justify-content: space-between; align-items: center;
    box-shadow: 0 4px 12px rgb(0 74 173 / 0.3);
}
header h1 { margin: 0; font-size: 1.8rem; font-weight: 700; }
main {
    width: 100%; max-width: 950px; background: #fff;
    border-radius: 0 0 8px 8px; padding: 2rem; box-shadow: 0 8px 24px rgb(0 0 0 / 0.15);
    margin-bottom: 50px;
}
form select {
    padding: 0.4rem 0.8rem; font-size: 1rem; border-radius: 6px; border: 1.5px solid #004aad;
    font-weight: 600;
}
table {
    width: 100%; border-collapse: collapse; margin-top: 2rem;
    box-shadow: 0 3px 12px rgb(0 0 0 / 0.1);
}
th, td { padding: 12px 16px; text-align: center; border-bottom: 1px solid #ddd; }
th { background: #004aad; color: #fff; font-weight: 700; }
td.subject { text-align: left; font-weight: 600; color: #004aad; }
.term-card {
    padding: 0.75rem; border-radius: 10px; color:#fff; flex:1; min-width:140px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex; flex-direction: column; align-items:center;
}
.term-card:hover {
    transform: translateY(-5px); box-shadow: 0 10px 25px rgb(0 0 0 / 0.2);
}
.term-title { font-weight:700; font-size:0.95rem; margin-bottom:0.4rem; text-transform:uppercase; }
.term-grades div { margin:2px 0; font-weight:600; }
.grade-A{ color:#2ecc71; } .grade-B{ color:#3498db; } .grade-C{ color:#f1c40f; }
.grade-D{ color:#e67e22; } .grade-F{ color:#e74c3c; }
.summary { margin-top: 2rem; font-weight: 700; font-size: 1.1rem; text-align: center; }
.progress-bar { height:20px; border-radius: 10px; background:#dfe6e9; margin:0.5rem 0; overflow:hidden; }
.progress-fill { height:100%; border-radius:10px; background:linear-gradient(90deg,#27ae60,#2ecc71); text-align:center; color:#fff; font-weight:700; line-height:20px; }
button.logout-btn {
    margin-top: 1.5rem; display: block; background: #2980b9; color:#fff;
    padding:10px 20px; border:none; border-radius:25px; cursor:pointer;
    font-weight:700; transition: 0.3s;
}
button.logout-btn:hover { background:#1f618d; }
button.download-btn {
    margin: 2rem auto 1rem auto; display: block;
    background-color: #27ae60; color: #fff; border: none; padding: 12px 36px;
    font-weight: 700; border-radius: 25px; cursor: pointer; font-size: 1rem;
    box-shadow: 0 6px 14px rgb(39 174 96 / 0.7); transition: background-color 0.3s ease, transform 0.2s ease;
}
button.download-btn:hover { background-color: #1e8449; transform: scale(1.05); }
@media print { button.download-btn, button.logout-btn, form { display: none; } body { background: white; } }
</style>
</head>
<body>
<header>
    <h1>Royal Science Academy</h1>
    <form method="GET">
        <button type="submit" name="logout" class="logout-btn">Logout</button>
    </form>
</header>
<main>
    <h2>Student Result</h2>
    <form method="POST">
        <label>Select Term:</label>
        <select name="term" onchange="this.form.submit()">
            <?php foreach(['First Term','Second Term','Third Term'] as $t): ?>
            <option value="<?= $t ?>" <?= $termSelected==$t?'selected':'' ?>><?= $t ?></option>
            <?php endforeach; ?>
        </select>
    </form>

    <table>
        <thead>
            <tr>
                <th>Subject</th>
                <th>Grades</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($grades as $subject => $termData): ?>
            <tr>
                <td class="subject"><?= htmlspecialchars($subject) ?></td>
                <td>
                    <div style="display:flex; gap:1rem; flex-wrap:wrap;">
                    <?php foreach($termsToShow as $term):
                        if(isset($termData[$term])):
                            $g=$termData[$term];
                            $bgColor = $term=='First Term'?'#3498db':($term=='Second Term'?'#e67e22':'#27ae60');
                    ?>
                    <div class="term-card" style="background:<?=$bgColor?>;">
                        <div class="term-title"><?= $term ?></div>
                        <div class="term-grades">
                            <div>A: <?= $g['assignment'] ?></div>
                            <div>T: <?= $g['test'] ?></div>
                            <div>E: <?= $g['exam'] ?></div>
                            <div class="grade <?= 'grade-'.$g['letter'] ?>">Total: <?= $g['total'] ?> (<?= $g['letter'] ?>)</div>
                        </div>
                    </div>
                    <?php endif; endforeach; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="summary">
        <p>Cumulative Average: <?= number_format($cumulativeAverage,2) ?>%</p>
        <div class="progress-bar">
            <div class="progress-fill" style="width:<?= number_format($cumulativeAverage,2) ?>%"><?= number_format($cumulativeAverage,2) ?>%</div>
        </div>
        <p>Overall Position: <?= htmlspecialchars($overallPosition) ?></p>
        <button class="download-btn" onclick="window.print()">Download PDF</button>
    </div>
</main>
</body>
</html>
